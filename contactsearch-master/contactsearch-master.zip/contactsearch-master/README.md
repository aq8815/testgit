# contactsearch

Android通讯录搜索

# 拼音匹配名称查询号码,实现高亮
![](https://github.com/HannyYaung/images/blob/master/searchImages/2017-05-27-08mz01.gif)

![](https://github.com/HannyYaung/images/blob/master/searchImages/2017-05-27-09mz02.gif)

![](https://github.com/HannyYaung/images/blob/master/searchImages/2017-05-27-08mz03.gif)

![](https://github.com/HannyYaung/images/blob/master/searchImages/2017-05-27-09mz04.gif)
